#game_poging_5

from game_engine_5 import setup_game
screen_width = 100

setup_game()